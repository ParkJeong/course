package chapter06;

public class StudentTest6 {
	public static void main(String[] args) {
		Student3 stu1 = new Student3();
		
		Student3 stu2 = new Student3();
		
		System.out.println(stu1.cardNum);
		System.out.println(stu2.cardNum);
		
	}
	
	
}
