package thread.runnable;

public class MainClass {
	public static void main(String[] args) {
		//Runnable을 상속받은 클래스는 직접 Thread클래스에 전달해서 실행한다.
		ThreadTest t = new ThreadTest();
		
		Thread thread = new Thread(t, "쓰레드1"); // 동작시킬 클래스, 이름
		thread.start(); // 쓰레드 시작
		
		System.out.println("메인종료~~~");
	}
}
