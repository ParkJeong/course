package thread.ex01;

public class ThreadTest implements Runnable{
	
	int num = 0;
	
	@Override
	public synchronized void run() {
		
		for(int i = 1; i <= 10; i++) {
			
			// 현재 실행 중인 쓰레드 이름이 A면
			if(Thread.currentThread().getName().equals("A")) {
				num++;
			}
			System.out.println("현재쓰레드:" + Thread.currentThread().getName() + ", num:" + num);
//			
//			try {
//				Thread.sleep(1000);
//			} catch (InterruptedException e) {
//				e.printStackTrace();
//			}
		}
	}
}
