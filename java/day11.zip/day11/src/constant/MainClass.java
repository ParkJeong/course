package constant;

public class MainClass {
	public static void main(String[] args) {
		System.out.println("원주율: " + Const.PI);
		System.out.println("산소질량: " + Const.O2);
		System.out.println("지구반지름: " + Const.EARTH_RADIUS);
	}
}
