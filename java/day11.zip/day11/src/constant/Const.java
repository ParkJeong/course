package constant;

public class Const {
	public static final double PI = 3.141592;
	public static final int O2 = 32;
	public static final long EARTH_RADIUS = 6400L;
}
