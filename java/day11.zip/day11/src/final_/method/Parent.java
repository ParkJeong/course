package final_.method;

// class에 final이 붙으면 상속 금지
public class Parent {
	public void method1() {}
	public final void method2() {}
}
