package final_.method;

public class Child extends Parent{

}
