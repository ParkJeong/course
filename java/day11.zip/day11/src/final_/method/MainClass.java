package final_.method;

public class MainClass {
	public static void main(String[] args) {
		
		Person park = new Person("123123", "박한");
		
		Person kim = new Person("456456", "김종");
		kim.name = "김대만";
	//	kim.nation = "미국";
		
	}
}
