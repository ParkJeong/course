package practice;

public class GenericClassTester {
	static class GenericClass<T> {
		private T xyz;
		GenericClass(T t) {
			xyz = t;
		}
		T getXyz() {
			return xyz;
		}
	}
}
