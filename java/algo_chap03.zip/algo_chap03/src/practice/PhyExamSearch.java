package practice;

import java.util.Arrays;
import java.util.Scanner;
import java.util.Comparator;

public class PhyExamSearch {
	static class PhyscData {
		private String name;
		private int height;
		private double vision;
		
		public PhyscData(String name, int height, double vision) {
			this.name = name;
			this.height = height;
			this.vision = vision;
		}
		
		@Override
		public String toString() {
			return name + " " + height + " " + vision;
		}
		
		public static final Comparator<PhyscData> HEIGHT_ORDER
		 = new HeightOrderComparator();
		
		private static class HeightOrderComparator implements Comparator<PhyscData> {
			@Override
			public int compare(PhyscData d1, PhyscData d2) {
				return (d1.height > d2.height) ?  1 :
					   (d1.height < d2.height) ? -1 : 0;
			}
		}
		
		public static final Comparator<PhyscData> VISION_ORDER
		= new VisionOrderComparator();
		
		private static class VisionOrderComparator implements Comparator<PhyscData> {

			@Override
			public int compare(PhyscData d1, PhyscData d2) {
				return (d1.vision > d2.vision) ? -1 :
					   (d1.vision < d2.vision) ?  1 : 0;
			}
			
		}
	}
	
	public static void main(String[] args) {
		int idx = Arrays.binarySearch(arr, new PhyscData("", height, 0.0), PhyscData.HEIGHT_ORDER);
	}
}
