package day01;

public class HelloJava {
	public static void main(String[] args) {
//		
		
//		\n은 줄바꿈 명령문입니다.
		/*
		 * 주석
		 * */
		System.out.print("Hello World?\n");
		System.out.print("안녕하세요\n");
		System.out.print("1\n");
		System.out.print(1);
	}
}
