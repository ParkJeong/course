package modi.constructor.pac1;

public class A {

	A a1 = new A(1);
	A a2 = new A(true);
	A a3 = new A("가");
	
	public A(int i){}
	
	A(boolean b){}
	
	private A(String s){}
	
}
