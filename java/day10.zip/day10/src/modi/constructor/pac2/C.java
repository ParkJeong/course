package modi.constructor.pac2;

import modi.constructor.pac1.A;

public class C {
	A a1 = new A(1);
	A a2 = new A(true);
	A a3 = new A("가");

}
