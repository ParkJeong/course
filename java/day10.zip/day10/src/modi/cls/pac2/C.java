package modi.cls.pac2;

import modi.cls.pac1.*;

public class C {
	A a = new A();
	B b = new B();
}
