package modi.cls.pac1;

// 클래스에 붙는 접근제어자는 public, default 밖에 없다.
// default - 접근제어자를 붙이지 않는 상태
class A {

}
