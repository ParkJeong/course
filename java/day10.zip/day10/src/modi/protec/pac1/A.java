package modi.protec.pac1;

public class A {

	/*
	 * protected는 기본적으로 같은 패키지에서만 사용이 가능하다.
	 * 단, 패키지가 다르더라도, 상속관계에서 super를 통한 참조가 가능하다.
	 * 
	 */
	
	protected boolean bool;
	
	protected A() {
		
	}
	
	protected void method() {
		
	}
}
