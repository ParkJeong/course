package encap.good;

public class Member {
	private String id;
	private String pw;
	private String email;
	private String address;
	private int zipNum;
	private int phone;
	
	
}
