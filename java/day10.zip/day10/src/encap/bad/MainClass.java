package encap.bad;

public class MainClass {
	public static void main(String[] args) {
		
		MyDate me = new MyDate();
		me.year = 2020;
		me.month = 13;
		me.day = 100;
		me.ssn = "???";
		me.showInfo();
		
		
	}
}
