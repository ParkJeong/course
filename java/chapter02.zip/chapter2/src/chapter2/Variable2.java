package chapter2;

public class Variable2 {
	public static void main(String[] args) {
		int level = 10;
		System.out.println(level);
	}
}
