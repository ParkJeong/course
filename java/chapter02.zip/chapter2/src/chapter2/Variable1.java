package chapter2;

public class Variable1 {
	public static void main(String[] args) {
//		int level;
//		level = 10;
//		System.out.println(level);
		
		int age;
		age = 29;
		System.out.println(age);
	}
}
