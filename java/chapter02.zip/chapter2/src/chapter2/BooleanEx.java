package chapter2;

public class BooleanEx {
	public static void main(String[] args) {
		boolean isMarried = true;
		System.out.println(isMarried);
	}
}
