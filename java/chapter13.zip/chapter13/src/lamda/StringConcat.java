package lamda;

@FunctionalInterface
public interface StringConcat {
	public void makeString(String s1, String s2);
}
