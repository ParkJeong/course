package inherit.good;

public class Student extends Person{
	String studentId;
}
