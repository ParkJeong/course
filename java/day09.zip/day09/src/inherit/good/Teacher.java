package inherit.good;

public class Teacher extends Person{
	String subject;
}
