package inherit.bad;

public class Student {
	String name;
	int age;
	String studentId;
	
	String info() {
		return "이름:" + name + ", 나이:" + age;
	}
}
