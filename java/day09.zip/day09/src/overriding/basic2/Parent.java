package overriding.basic2;

public class Parent {

	void method01() {
		System.out.println("부모의 1번 메서드 실행");
	}
	
	void method02() {
		System.out.println("부모의 2번 메서드 실행");
	}
}
