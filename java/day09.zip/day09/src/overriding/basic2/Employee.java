package overriding.basic2;

public class Employee extends Person{
	String department;
}
