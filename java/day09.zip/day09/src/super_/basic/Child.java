package super_.basic;

public class Child extends Parent{
	
}
