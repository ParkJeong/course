package this_.basic;

public class MainClass {
	public static void main(String[] args) {
//		Person p = new Person("홍길동", 20);
//		Person p2 = new Person("홍길자");
//		Person p3 = new Person();
		
		
		Student s = new Student("이순신", 30, "123");
		System.out.println(s.info());
		
	}
}
