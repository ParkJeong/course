package generic.bad;

public class Person {

}
