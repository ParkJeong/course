package generic.basic1;

public class Person {

}
