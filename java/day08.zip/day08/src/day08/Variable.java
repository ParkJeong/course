package day08;

public class Variable {
	// 멤버변수: 초기화하지 않으면 자동으로 초기화
	int a;
	
	// 메서드
	void printNum() {
		int b = 1;
		System.out.println("멤버변수:" + a);
		System.out.println("멤버변수:" + b);
	}
	
}
