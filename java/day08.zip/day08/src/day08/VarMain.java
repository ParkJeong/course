package day08;

public class VarMain {

	public static void main(String[] args) {
		Variable var = new Variable();
		var.printNum();
	}
}
