package import_ex;

import java.util.Scanner;

import com.abc.Abc;
import com.def.Def;

// 클래스 선언부 위에 패키지명을 포함한 전체경로를 적는다.

//import fruit.Apple;
//import fruit.Orange;
import fruit.*;

public class MainClass {
	public static void main(String[] args) {
		Apple a = new Apple();
		
		Abc abc = new Abc();
		Def def = new Def();
		
		Scanner scan = new Scanner(System.in);
		
	}
}
