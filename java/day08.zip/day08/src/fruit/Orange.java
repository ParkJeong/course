package fruit;

public class Orange {

}
