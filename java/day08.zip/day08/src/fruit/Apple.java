package fruit;

public class Apple {

}
