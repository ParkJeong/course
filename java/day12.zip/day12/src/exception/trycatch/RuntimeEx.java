package exception.trycatch;

public class RuntimeEx {
	public static void main(String[] args) {
		
		// 실행 예외의 대표적인 종류
		// ArrayIndex
//		int[] arr = {1, 2, 3, 4, 5};
//		System.out.println(arr[5]);
		
		//Classcasting
//		String s = (String)new Object();
		
		//NumberFormat
//		String s = "10-";
//		Integer.parseInt(s);
		
		//NullPointer
//		String s = null;
//		s.charAt(10);
	}
}
