package abs.bad;

public class HeadStore {
	public void apple( ) {
		System.out.println("각 지점에서 가격을 제시하세요");
	}

	public void banana( ) {
		System.out.println("각 지점에서 가격을 제시하세요");
	}

	public void melon( ) {
		System.out.println("각 지점에서 가격을 제시하세요");
	}

	public void orange( ) {
		System.out.println("각 지점에서 가격을 제시하세요");
	}


}
