package abs.good;

public class Store extends HeadStore{

	@Override
	public void apple() {
		// TODO Auto-generated method stub
		System.out.println("서울 지점의 사과 500원");
	}

	@Override
	public void banana() {
		// TODO Auto-generated method stub
		System.out.println("서울 지점의 바나나 700원");
		
	}

	@Override
	public void melon() {
		// TODO Auto-generated method stub
		System.out.println("서울 지점의 멜론 900원");
		
	}

	@Override
	public void orange() {
		// TODO Auto-generated method stub
		System.out.println("서울 지점의 오렌지 1500원");
		
	}

	
}
