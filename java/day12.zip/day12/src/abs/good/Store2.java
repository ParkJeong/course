package abs.good;

public class Store2 extends HeadStore{

	@Override
	public void apple() {
		// TODO Auto-generated method stub

		System.out.println("부산 지점의 사과 1000원");		
	}

	@Override
	public void banana() {
		// TODO Auto-generated method stub

		System.out.println("부산 지점의 바나나 1300원");		
		
	}

	@Override
	public void melon() {
		// TODO Auto-generated method stub

		System.out.println("부산 지점의 멜론 1900원");		
		
	}

	@Override
	public void orange() {
		// TODO Auto-generated method stub

		System.out.println("부산 지점의 오렌지 2500원");		
		
	}

}
