package inter.basic2;

public interface IPet {
	public void play();
}
