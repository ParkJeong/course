package inter.basic2;

public class Tiger extends Animal{

	@Override
	public void eat() {
		// TODO Auto-generated method stub
		System.out.println("호돌이는 고기를 좋아해요.");
	}

}
