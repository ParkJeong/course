package inter.basic2;

public class Shark extends Fish{

	@Override
	public void swim() {
		// TODO Auto-generated method stub
		System.out.println("상어는 바다에서 헤엄친다.");
	}

}
