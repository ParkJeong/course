package inter.basic;

public interface Inter2 {
	int ABC = 2;
	void method2();
}
