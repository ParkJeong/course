package exception;

public class AutoCloseObj implements AutoCloseable{
	@Override
	public void close() throws Exception{
		System.out.println("리소스가 close() 되었습니다.");
		/*
		 * 시스템 리소시인 경우에는 
		 * 파일 스트림을 닫거나 
		 * 네트워크 연결을 해제하는
		 * 코드를 작성해야한다. 
		 * 여기서는 close()메서드가
		 *  제대로 호출되는지
		 * 알아보기 위해 출력문만 남긴다.
		 */
	}
}
