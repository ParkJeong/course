package exception;

public class PasswordException extends Exception{
	public PasswordException(String message) {
		super(message);
	}
}
