package testdrivendevelopment;

public class BeginnerLevel extends PlayerLevel{

	@Override
	public void run() {
		// TODO Auto-generated method stub
		System.out.println("천천히 달린다");
	}

	@Override
	public void jump() {
		// TODO Auto-generated method stub
		System.out.println("점프 못함");
	}

	@Override
	public void turn() {
		// TODO Auto-generated method stub
		System.out.println("돌지 못함");
	}

}
