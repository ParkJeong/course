package testdrivendevelopment;

public class AdvancedLevel extends PlayerLevel{

	@Override
	public void run() {
		// TODO Auto-generated method stub
		System.out.println("빨리 달린다");
	}

	@Override
	public void jump() {
		// TODO Auto-generated method stub
		System.out.println("멀리 점프");
	}

	@Override
	public void turn() {
		// TODO Auto-generated method stub
		System.out.println("돌지 못함");
	}

}
