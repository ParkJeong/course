package chapter09;

public class DeskTop extends Computer{

	@Override
	public void display() {
		// TODO Auto-generated method stub
		System.out.println("Desktop display()");
	}

	@Override
	public void typing() {
		// TODO Auto-generated method stub
		System.out.println("Desktop typing()");
	}

}
