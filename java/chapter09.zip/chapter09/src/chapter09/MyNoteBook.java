package chapter09;

public class MyNoteBook extends NoteBook{

	@Override
	public void typing() {
		// TODO Auto-generated method stub
		System.out.println("MyNoteBook typing()");
	}

}
