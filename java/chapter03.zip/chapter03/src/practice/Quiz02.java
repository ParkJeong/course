package practice;

public class Quiz02 {
	public static void main(String[] args) {
		int num;
		num = -5 + 3 * 10 /2;
		System.out.println(num); // 10

		System.out.println("----------------------------------------");
		
		num = 10;
		System.out.println(num);	// 10
		System.out.println(num++);	// 10
		System.out.println(num);	// 11
		System.out.println(--num);	// 10
		
		System.out.println("----------------------------------------");
		
		int num1 = 10;
		int num2 = 20;
		boolean result;
		
		result = ((num1 > 10) && (num2 > 10));
		System.out.println(result);				// false
		result = ((num1 > 10) || (num2 > 10));
		System.out.println(result);				// true
		System.out.println(!result);			// false
		
		System.out.println("----------------------------------------");
		
		num1 = 2;	// 0010
		num2 = 10;	// 1010
		
		System.out.println(num1 & num2);	// 0000	0010	2
		System.out.println(num1 | num2);	// 0000	1010	10
		System.out.println(num1 ^ num2);	// 0000	1000	8
		System.out.println(~num1);			// 1111	1101	-3	
		
		System.out.println("----------------------------------------");
		num = 8;
		
		System.out.println(num += 10);	// 18
		System.out.println(num -= 10);	// 8
		System.out.println(num >>= 2);	// 2
		
		System.out.println("----------------------------------------");
		num = 10;
		num2 = 20;
		int result2 = (num >= 10) ? num2 + 10 : num2 - 10;
		
		System.out.println(result2);	// 30
		
	}
}
