package chapter10;

public interface X {
	void x();
}
