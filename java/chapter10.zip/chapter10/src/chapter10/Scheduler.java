package chapter10;

public interface Scheduler {
	public void getNextCall();
	public void sendCallToAgent();
}
