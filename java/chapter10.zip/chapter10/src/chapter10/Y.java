package chapter10;

public interface Y {
	void y();
}
