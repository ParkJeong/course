package chapter05;

public class Subject {
	String subjectName;
	int scorePoint;
}
