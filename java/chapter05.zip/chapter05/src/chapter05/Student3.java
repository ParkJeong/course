package chapter05;

public class Student3 {
	int studentId;
	String studentName;
	Subject Korean;
	Subject math;
}
