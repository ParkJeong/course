package chapter05;

public class Man {
	int age;
	String name;
	boolean isMarried;
	int numberOfChildren;
}
