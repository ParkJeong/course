package chapter05;

public class ShoppingMallOrder {
	String orderId;
	String customerId;
	int orderDate;
	String customerName;
	String productId;
	String shippingAddress;
}
